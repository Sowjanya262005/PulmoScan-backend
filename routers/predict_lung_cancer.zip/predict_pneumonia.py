# backend/routers/predict_pneumonia.py
from typing import Tuple, List
import io, base64
from PIL import Image
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import transforms, models
from fastapi import APIRouter, UploadFile, File, HTTPException, Query

from backend.services.grad_cam import generate_gradcam

router = APIRouter(prefix="/predict", tags=["Pneumonia"])

MODEL_PATH = r"E:\Torrent Downloads\lungcare-ai-starter-v2\backend\pneumonia_model.pth"
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
CLASS_NAMES: List[str] = ["NORMAL", "PNEUMONIA"]
IMG_SIZE = 224

inference_tfms = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225]),
])

def build_fallback_architecture(num_classes: int = 2) -> nn.Module:
    m = models.resnet18(weights=None)
    m.fc = nn.Linear(m.fc.in_features, num_classes)
    return m

def load_model(path: str) -> nn.Module:
    obj = torch.load(path, map_location=DEVICE)
    if isinstance(obj, nn.Module):
        model = obj
    elif isinstance(obj, dict):
        model = build_fallback_architecture(num_classes=len(CLASS_NAMES))
        state = obj.get("state_dict", obj)
        state = {k.replace("module.", ""): v for k, v in state.items()}
        model.load_state_dict(state, strict=False)
    else:
        raise RuntimeError("Unsupported .pth format.")
    return model.to(DEVICE).eval()

MODEL = load_model(MODEL_PATH)

def _read_image(file_bytes: bytes) -> Image.Image:
    return Image.open(io.BytesIO(file_bytes)).convert("RGB")

def _predict_image(img: Image.Image) -> Tuple[str, float, List[float], torch.Tensor]:
    tensor = inference_tfms(img).unsqueeze(0).to(DEVICE)
    with torch.no_grad():
        logits = MODEL(tensor)
        probs = F.softmax(logits, dim=1).cpu().numpy().ravel().tolist()
        idx = int(torch.argmax(logits, dim=1).item())
    return CLASS_NAMES[idx], float(probs[idx]), probs, tensor

@router.post("/pneumonia")
async def predict_pneumonia(
    file: UploadFile = File(...),
    explain: int = Query(0, description="1 to include Grad-CAM heatmap")
):
    if not file or not file.filename:
        raise HTTPException(status_code=400, detail="No file uploaded.")

    try:
        content = await file.read()
        img = _read_image(content)
        label, confidence, probs, tensor = _predict_image(img)

        explain_image_b64 = None
        if explain == 1:
            # target = predicted class
            target_idx = CLASS_NAMES.index(label)
            explain_image_b64 = generate_gradcam(MODEL, tensor, target_class=target_idx)

        return {
            "label": label,
            "confidence": round(confidence, 6),
            "probs": [round(p, 6) for p in probs],
            "classes": CLASS_NAMES,
            "filename": file.filename,
            "explain_requested": bool(explain),
            "explain_supported": True,
            "explain_image": explain_image_b64,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
